using Microsoft.Extensions.DependencyInjection;

namespace AabuReports.Core;

public static class CoreServiceCollectionExtensions
{
    public static IServiceCollection AddCore(this IServiceCollection services)
    {
        return services;
    }
}